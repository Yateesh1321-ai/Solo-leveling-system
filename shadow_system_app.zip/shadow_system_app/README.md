# Shadow System

A responsive, installable Progressive Web App inspired by anime-style RPG quest systems.

## Run locally
Open `index.html` in a modern browser. Core quest tracking and XP work locally. For install/offline support, serve this folder over HTTPS or localhost.

## Install on Android
1. Upload/deploy this folder to an HTTPS static host (for example GitHub Pages, Netlify, or Cloudflare Pages).
2. Open the deployed URL in Chrome on Android.
3. Use Chrome menu → **Install app** or **Add to Home screen**.

This project is a PWA, not a signed APK. It can be wrapped into an Android APK later using a Trusted Web Activity or Capacitor.

## Features
- Responsive overview dashboard and mixed blue/purple dark theme
- Daily quest checklist, XP, level progression and local save
- Five character attributes, shadow coins and activity log
- Weekly progress, weekly boss challenge and achievements
- Safe recovery protocol instead of harmful punishments
- Basic notification permission prompt
- Service worker caching for offline use after first visit

## Data
Progress is saved in browser localStorage on the device. It does not sync across devices or browsers. Clearing site data may erase progress; export/cloud sync is not included in this starter build.
